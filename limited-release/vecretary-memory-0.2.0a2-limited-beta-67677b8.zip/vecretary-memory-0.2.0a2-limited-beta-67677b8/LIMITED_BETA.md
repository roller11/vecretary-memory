# Vecretary Memory limited alpha

This is a small, invited evaluation package. It is an experimental prerelease, not a stable or production-certified release.

## What is included

- `wheel/`: installable application package built from the source snapshot in this bundle.
- `source.tar.gz`: product source, dashboard design, static images, documentation, and client examples from the same revision.
- `SHA256SUMS`: integrity checks for the source archive and application wheel.

The source snapshot excludes Git history, local databases, private runtime configuration, developer exports, and testbed data. The application source is licensed under the included MPL-2.0 license; third-party notices are included.

## Intended testers

This candidate targets Linux x86_64 and WSL2 Ubuntu with Python 3.11 or 3.12. Native Windows server support is not part of this limited package. It requires a separately installed local Ollama service and a compatible embedding model. Extract `source.tar.gz` into a new folder and follow the fresh isolated setup in its `README.md`.

Use a new empty data directory for evaluation. Do not point it at an existing memory database or import private memories. The dashboard is loopback-only and has no login or HTTPS; do not expose it to another machine or the internet. This alpha is not for regulated, hostile, or multi-user environments. Recall, privacy, availability, and support response times are not guaranteed.

This package was assembled from source revision `67677b8abb4adab38c5fb5b90f6f951a07013770`. Packaging integrity and wheel contents are checked. A clean guest installation of this newly rebuilt wheel has not been performed, so treat this as a controlled beta candidate and report installation problems before relying on it.

