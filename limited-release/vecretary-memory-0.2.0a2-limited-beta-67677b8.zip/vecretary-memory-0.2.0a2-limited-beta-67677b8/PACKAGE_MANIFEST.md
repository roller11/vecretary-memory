# Package manifest

- Package: Vecretary Memory limited alpha, version 0.2.0a2.
- Source branch: sqlite-alpha-0.2.0a2-staging.
- Source revision: 67677b8abb4adab38c5fb5b90f6f951a07013770.
- Target: Linux x86_64 / WSL2 Ubuntu; Python 3.11 or 3.12.
- Contents: complete tracked instinct/ runtime source and assets; product docs and examples; MPL-2.0 license and third-party notices; a wheel built from the source snapshot.
- The source archive contains 44 runtime Python modules. It excludes Git history, tests, DRAFT_EXPORT.json, local databases, private runtime configuration, and testbed data.
- Dashboard source inside the wheel matches the source snapshot byte-for-byte after normalizing line endings. The wheel includes the refined dark accent #176331, neutral light background #d9dcda, and the 256px logo route and asset.
- Wheel SHA-256: d4c2420d27df5eb37b35fac16869f04f574f5122888fcce8108cdb356ab8e0b6.
- Dashboard source SHA-256: 526f7ca42592cb985e1e5d91ff604ec90f3b789acf6f0d4b15567f640e5e5c6a.
- Logo asset SHA-256: 658fa802221e52dbfbbd05ce91ec7bf1a2cee663dec38eb37c0234daa9ac54c5.

Packaging checks passed: source export from a clean checkout, wheel build, wheel ZIP integrity, source/wheel dashboard match, CSS/logo presence, and a source archive scan for private paths and developer export files. The product test suite and clean guest installation were not run for this newly rebuilt wheel. This is a controlled beta candidate, not a release certification.

